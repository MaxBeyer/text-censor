package max.text_scrambler;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Scrambler 
{

	public String replaceSwears(String textBlock){
		Map<String, String> cursesAndSwears = getCursesAndSwears();
		for(Map.Entry<String, String> entry : cursesAndSwears.entrySet()){ 
			textBlock = textBlock.replaceAll(entry.getKey(), entry.getValue());
		}
		return textBlock;
	}

	public String reinsertSwears(String textBlock){
		Map<String, String> cursesAndSwears = getCursesAndSwears();
		for(Map.Entry<String, String> entry : cursesAndSwears.entrySet()){ 
			textBlock = textBlock.replaceAll(entry.getValue(), entry.getKey());
		}
		return textBlock;

	}

	public Map<String, String> getCursesAndSwears(){
		Map<String, String> cursesAndSwears = new HashMap<String, String>();
		for(String swear:listOfSwears){
			cursesAndSwears.put(swear, new StringBuilder(swear).reverse().toString());
		}
		return cursesAndSwears;
	}

	public List<String> listOfSwears = Arrays.asList("Test", "test", "one", "two", "three");
}
