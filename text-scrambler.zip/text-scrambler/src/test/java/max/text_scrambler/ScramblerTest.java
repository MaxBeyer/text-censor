package max.text_scrambler;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class ScramblerTest {
	
	public static String nsfwTextBlock = "Test test one two three";
	public static String sfwTextBlock = "tseT tset eno owt eerht";
	
	@Test
	public void replaceSwearsTest(){
		Scrambler scrambler = new Scrambler();
		String actualTextBlock = scrambler.replaceSwears(nsfwTextBlock);
		System.out.println(actualTextBlock);
		assertEquals(sfwTextBlock, actualTextBlock);
	}
	
	@Test
	public void  reinsertswearsTest(){
		Scrambler scrambler = new Scrambler();
		String actualTextBlock = scrambler.reinsertSwears(sfwTextBlock);
		System.out.println(actualTextBlock);
		assertEquals(nsfwTextBlock, actualTextBlock);
	}
}
